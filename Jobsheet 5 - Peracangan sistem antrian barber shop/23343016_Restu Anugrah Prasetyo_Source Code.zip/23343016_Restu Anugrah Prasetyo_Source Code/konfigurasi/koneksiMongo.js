// Utilitas koneksi database
const mongoose = require('mongoose');

let cached = global.mongoose;

if (!cached) {
    cached = global.mongoose = { conn: null, promise: null };
}

/**
 * Koneksi ke MongoDB dengan caching (untuk efisiensi di environment serverless)
 * @returns {Promise} Koneksi MongoDB
 */
async function connectDB() {
    if (cached.conn) {
        console.log('✅ Menggunakan koneksi MongoDB yang sudah ada (cached)');
        return cached.conn;
    }

    if (!cached.promise) {
        const mongoUri = process.env.MONGO_URI;

        if (!mongoUri) {
            throw new Error('❌ Variabel environment MONGO_URI belum diatur');
        }

        const opts = {
            bufferCommands: false,
            maxPoolSize: 10,
            serverSelectionTimeoutMS: 5000,
        };

        console.log('📡 Menghubungkan ke MongoDB...');

        cached.promise = mongoose.connect(mongoUri, opts)
            .then(() => {
                console.log('✅ Berhasil terhubung ke MongoDB');
                return mongoose;
            })
            .catch((err) => {
                console.error('❌ Gagal terhubung ke MongoDB:', err.message);
                throw err;
            });
    }

    try {
        cached.conn = await cached.promise;
        return cached.conn;
    } catch (error) {
        cached.promise = null;
        throw error;
    }
}

module.exports = { connectDB };
