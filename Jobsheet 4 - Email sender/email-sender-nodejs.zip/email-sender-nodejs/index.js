const nodemailer = require('nodemailer');

// konfigurasi transporter (SMTP Gmail)
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'anugrahprasetyo456@gmail.com',
    pass: 'qdkwtchhntaswnru'
  }
});

// detail email
const mailOptions = {
  from: 'EMAIL_PENGIRIM@gmail.com',
  to: 'EMAIL_TUJUAN@gmail.com',
  subject: 'Tes Email dari Node.js',
  text: 'Halo! Ini adalah email percobaan yang dikirim menggunakan Node.js dan Nodemailer.'
};

// kirim email
transporter.sendMail(mailOptions, function (error, info) {
  if (error) {
    console.log('Email gagal dikirim:', error);
  } else {
    console.log('Email berhasil dikirim:', info.response);
  }
});
